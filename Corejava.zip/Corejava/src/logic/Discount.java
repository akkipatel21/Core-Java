package logic;

public class Discount
{
	public static void main(String[] args)
	{

	}
}
