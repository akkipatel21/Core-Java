package logic;


public class Fibonaci
{
public static void main(String[] args)
{
	int a=1,b=1,n;
	
	//fibonaci--------------------------------- 
	/*int a=0,b=1,n;
		for(int i=0; i<10; i++) {
		System.out.println(a);
		 n=a+b;
		 a=b;
		 b=n;
	}*/
	
	
	//Swaping-------------------------------------
/*	n=a;
	a=b;
	b=n;
	System.out.println(a+" "+b);*/
	
	
	
	int f = 0;
    // int numUpto = 10; // number of series upto - change accordingly
     for(int t = 1; f < 35; t = f + (f = t))
     {         System.out.print(f + " ");
     
     }
     
	 
}
}	 
	 
	 //Factorial-----------------------------------
	/*for(int i=1; i<6; ++i) {
		 a=a*i;
	System.out.println(a);
	}*/
	

	

