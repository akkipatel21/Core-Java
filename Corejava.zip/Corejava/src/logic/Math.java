package logic;

import java.util.Scanner;

public class Math
{
	static String a1;
	static String a2;

	public static void main(String[] args)

	{
		System.out.println("Enter the No. : ");
		Scanner s = new Scanner(System.in);
		String a = s.nextLine();
		int b = a.length() / 2 ;
		a1 = a.substring(0, b);
		a2 = a.substring(b, a.length());
		if ((a.length() == 3))
		{ if (a.endsWith("0"))
			{	int b1 = a.length() / 2;
				a1 = a.substring(0, b1);
				a2 = a.substring(b1, a.length());
			} else
			{	int b1 = a.length() / 2;
				a1 = a.substring(0, b1 + 1);
				a2 = a.substring(b1 + 1, a.length());
			}
		} 
		while (a2.startsWith("0"))
		{
			b = b + 1;
			a1 = a.substring(0, b - 1);
			a2 = a.substring(b - 1, a.length());
		}
		System.out.println(a1 + " " + a2);
		int result = Integer.parseInt(a1);
		int result1 = Integer.parseInt(a2);
		System.out.println("first divisor. : ");
		Scanner s1 = new Scanner(System.in);
		int first = s1.nextInt();
		System.out.println("Second divisor : ");
		int second = s1.nextInt();
		s1.close();
		if (((result % first == 0) || (result % second == 0)) && ((result1 % second == 0) || (result1 % first == 0)))
		{
			System.out.println("yes");
		} else
		{
			System.out.println("No");
		}
	}
}
