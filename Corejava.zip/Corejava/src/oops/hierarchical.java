package oops;

class a {
	void move() {
		System.out.println("moving...");
	}
}

class b extends a {
	void ride() {
		System.out.println("riding...");
	}
}

class c extends a {
	void fun() {
		System.out.println("fun...");
	}
}

class TestInheritance3 {
	public static void main(String args[]) {
		c obj = new c();
		obj.move();
		obj.fun();
	}
}