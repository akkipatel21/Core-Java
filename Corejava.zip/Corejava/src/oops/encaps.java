package oops;

public class encaps {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		encapsulation a=new encapsulation();
		a.setName("eSense");
		System.out.println(a.getName());

	}

}
