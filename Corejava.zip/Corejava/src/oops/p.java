package oops;



	abstract class Y{
		abstract void f1();
		
	} 
class S extends Y{
	void f1(){System.out.println("eSense...");}
} 

class G extends Y{
	void f1(){System.out.println("learning...");}
} 
class p
{public static void main(String []args){
	Y obj=new S();
	obj.f1();
}
}