package oops;
interface I1{void f1();}
interface I2{void f2();}
interface I3{void f3();}


class Q implements I1,I2{
	public void f1(){
		System.out.println("hii from f1");}

	public void f2(){
		System.out.println("hii from f2");}
}

public class interface11 {

	public static void main(String[] args) {
	Q obj =new Q();
	obj.f1();
	obj.f2();
	}

}
