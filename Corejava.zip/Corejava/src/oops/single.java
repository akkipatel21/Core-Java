package oops;
 class qw {

	void f1() {
		System.out.println("parent...");
	}
}

class qe extends qw {
	void f2() {
		System.out.println("child...");
	}

	
}


public class single {

		public static void main(String args[]) {
			qe d = new qe();
			d.f2();
			d.f1();
	}

}
