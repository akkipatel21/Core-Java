package oops;

class abc {
	void hi() {
		System.out.println("hi...");
	}
}

class bc extends abc {
	void java() {
		System.out.println("java...");
	}
}

class dc extends bc {
	void programmer() {
		System.out.println("programer...");
	}
}

class multilevel {
	public static void main(String args[]) {
	dc obj = new dc();
		obj.hi();
		obj.java();
		obj.programmer();
}
}