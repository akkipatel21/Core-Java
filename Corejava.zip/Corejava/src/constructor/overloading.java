package constructor;

public class overloading {
	  int id;
	    String name;
	    int age;
	    overloading(int i,String n){
	    id = i;  
	    name = n;  }
	    
	    overloading(int i,String n,int a){
		    id = i;  
		    name = n;  
	        age = a; }
	    
	    void display()
	      {System.out.println(id+" "+name+ " "+ age);}  
		 

	public static void main(String[] args) {
		overloading a=new overloading(1,"abc");
		overloading a1=new overloading(1,"abc",12);
		a.display();
		a1.display();
		
		
	}

}
