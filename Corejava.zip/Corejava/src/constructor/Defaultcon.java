package constructor;

public class Defaultcon {

       int id;
       String name;
       void dis()
           {System.out.println(id +" "+ name );}
      
     	public static void main(String[] args) {
     		 Defaultcon a =new Defaultcon();
     		 Defaultcon b =new Defaultcon();
      	    	a.dis();
      	    	b.dis();

	}

}
