package constructor;

public class paracon {
    int id;
    String name;
    
    paracon(int i,String n){
    id = i;  
    name = n;  }
    
    void display()
      {System.out.println(id+" "+name);}  
	 
    
    public static void main(String[] args) {
		paracon a=new paracon(11,"akash");
		paracon b=new paracon(21,"parth");
	    a.display();
	    b.display();
	}

}
