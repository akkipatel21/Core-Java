package aStatic;

class thiskey {
	  int var= 5;
	  void method(int var) {
		    var = 10;
		    System.out.println(" Instance variable :" + this.var);
		    System.out.println(" Local variable :" + var);
		  }
		  void method() {
		    int var = 40;
		    System.out.println("instance variable :" + this.var);
		    System.out.println("variable :" + var);
		  }
		  
	  public static void main(String args[]) {
	    thiskey obj = new thiskey();
	    obj.method(20);
	    obj.method();
	  }
}
	 