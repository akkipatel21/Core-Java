package aStatic;

public class stati {
	   int no;  
	   String name;  
	   static String abc ="hello";  
	     
	   stati(int r,String n){  
	   no = r;  
	   name = n;  
	   }  
	 void display (){System.out.println(no+" "+name+" "+abc);}  
	  
	 public static void main(String args[]){  
	 stati s1 = new stati(1,"akash");  
	 stati s2 = new stati(2,"world");  
	   
	 s1.display();  
	 s2.display();  
	 }  
	}  
