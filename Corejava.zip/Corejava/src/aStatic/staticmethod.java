package aStatic;

public class staticmethod {
  int x=10;
  static int y;
  static void show()
       {System.out.println("static method");
       System.out.println("y :" +y);}
 
  
	public static void main(String[] args) {
	staticmethod.show();
//	    show();
		staticmethod a=new staticmethod();
		
		
		 System.out.println("x :" +a.x);
	}

}
