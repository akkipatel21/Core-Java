package exception;

public class ex6 {

	 void f1(){  
		    int data=50/0;  
		      }  
     void f2(){  
		    f1();  
		  }  
     void f3(){  
		   try{  
		    f2();  
		   }
		   
		   catch(Exception e){System.out.println("arithmetic ex");}  
		  }  
		  public static void main(String args[]){  
		   ex6 obj=new ex6();  
		   obj.f3();  
		   System.out.println("eSense");  
		  }  
		}  