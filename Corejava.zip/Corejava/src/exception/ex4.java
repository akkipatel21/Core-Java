package exception;

public class ex4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		  try{  
			    int a[]=new int[5];  
			    a[6]=30/0;  
			   }  
		  

		   catch(Exception e)
		       {System.out.println("exception");}  
//		     catch(ArrayIndexOutOfBoundsException e)
//	              {System.out.println("outofbound");}  
		 
		  
//			   catch(ArithmeticException e)
//			     {System.out.println("airtmetic");}  
//			 
			  
			   System.out.println("rest of the code...");  
			 }  
}