package exception;

public class ex2 {

	public static void main(String[] args) {
      try{
    	  int a=5/0;
    	  }
      catch(ArithmeticException e)
      {
          	
         e.printStackTrace();
      //System.out.println(e);
      }
    finally{System.out.println("finally....");
    	}
    }

}
