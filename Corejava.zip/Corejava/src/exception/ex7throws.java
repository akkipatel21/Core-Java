package exception;

import java.io.IOException;

class ex {

	void fun() throws IOException   {
		throw new IOException("error");
	}
}

public class ex7throws {
	public static void main(String args[]) {
		try {
			ex e = new ex();
			e.fun();}
		catch (Exception e) {
			System.out.println("eSense");
		   }
           System.out.println("learning...");
	}
}