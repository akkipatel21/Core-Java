package exception;

public class ex6throw {

	static void applicable(int age){
  	  if(age<18)
  		  throw new ArithmeticException("not applicable for election");
  	  else
  		  System.out.println("applicable for election");
	}

  	  public static void main(String[] args) {
		// TODO Auto-generated method stub
      applicable(15);  	
    
	}

}
