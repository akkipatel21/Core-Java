package exception;

public class ex3 {

	public static void main(String[] args) {
		  try{  
			    int a[]=new int[5];  
			    a[6]=30/0;  
     //        int i=a[7];  
			   }  
		     catch(ArrayIndexOutOfBoundsException e)
	              {System.out.println("outofbound");}  
		 
		  
			   catch(ArithmeticException e)
			    {System.out.println("airtmetic");}  
			 
			   catch(Exception e)
			       {System.out.println("exception");}  
			  
			   System.out.println("rest of the code...");  
			 }  
			
	

}
