package exception;

public class ex1 {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
       String S=null;
       System.out.println(S.length());
	}

}
