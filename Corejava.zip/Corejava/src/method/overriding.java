package method;

public class overriding {

	public void disp() {
		System.out.println(" parent class");
	}
}

class over extends overriding {

	public void disp() {
		System.out.println(" Child class");
	}

	public void newMethod() {
		System.out.println("new method");
	}

	public static void main(String args[]) {

		overriding obj = new overriding();
		obj.disp();

		overriding obj2 = new overriding();
		obj2.disp();
	}
}
