package method;

class overload {
	public void disp(char c) {
		System.out.println(c);
	}

	public void disp(char c, int num) {
		System.out.println(c+ " " +num );
	}
}

public class overloading {
	public static void main(String[] args) {
		overload a=new overload();
		a.disp('I');
		a.disp('a',10);
		

	}

}
