package method;

class ABC {
	public void Method() {
		System.out.println("parent");
	}
}

class usesuper extends ABC {
	public void Method() {
		super.Method();
		System.out.println("child");

	}

	public static void main(String args[]) {
		usesuper obj = new usesuper();
		obj.Method();
	}
}
