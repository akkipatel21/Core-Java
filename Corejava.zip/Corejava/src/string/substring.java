package string;

public class substring {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String s="eSenseLearning";
		 String w=" Navneet";
		 String s3=w.trim();
		 String s1=s.substring(8);
		 String s2=s.substring(4, 9);
		 System.out.println(s1);
		 System.out.println(s2);
		 System.out.println(s3);
	}

}
