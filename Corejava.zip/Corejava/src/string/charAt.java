package string;

public class charAt {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String s1="0123456 789"; 
		 char ch=s1.charAt(8);
		 System.out.println(ch);
	}

}
