package string;

public class concate {

	
	public static void main(String[] args) {
		String s1="hello";
		String s2=new String("    akash");
        String s3=s1.concat(s2);
        System.out.println(s3);
	}

}
