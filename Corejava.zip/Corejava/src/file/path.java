package file;

import java.io.File;
import java.io.IOException;

public class path
{
    public static void main(String[] args) throws IOException{
	File file = new File("d:\\path.txt");
	boolean f= file.createNewFile();
	String path = file.getAbsolutePath();
	String s1 = file.getCanonicalPath();
	File s2 = file.getAbsoluteFile();
	System.out.println(s1);
	System.out.println(path);
	System.out.println(s2);
    }
}
