package file;

import java.io.*;  
public class Writer {  
    public static void main(String[] args) {  
        try {  
            FileWriter w = new FileWriter("output.txt");  
            String s = "eSense";  
            w.write(s);  
            w.close();  
            System.out.println("success");  
           } 
        catch (IOException e) {  
            e.printStackTrace();  
        }  
    }  
}  