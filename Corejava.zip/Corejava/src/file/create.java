package file;



import java.io.File;
import java.io.IOException;

public class create {
	public static void main(String[] args) {
		try {
			File f = new File("d:\\secondfile.txt");
			boolean file = f.createNewFile();
			if (file)
				System.out.println("created");
			else
				System.out.println("already exists");
		} catch (IOException e) {
			System.out.println("exception occured");
			e.printStackTrace();

		}

	}

}
