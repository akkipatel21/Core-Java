package file;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

public class file2 {

	public static void main(String[] args) throws IOException {
	File f=new File("D:/Akash/Corejava/File2.txt");
	f.createNewFile();
	InputStreamReader isr=new InputStreamReader(System.in);
	BufferedReader br=new BufferedReader(isr);
	String S=br.readLine();
	System.out.println("String is: "+S);
	System.out.println("length of String is: "+S.length());
	char a= S.charAt(2);
	System.out.println("char at index 2 is "+a);
	System.out.println("file name is :"+f.getName());
	System.out.println("file path is :"+f.getPath());
	boolean b=f.delete();
	System.out.println("file deleted: "+b);
	boolean d=f.exists();
	System.out.println("file is exixsts or not "+d);
	}
}
