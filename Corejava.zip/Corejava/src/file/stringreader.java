package file;
import java.io.*;

public class stringreader {


	public static void main(String[] args) throws IOException {
		 String srg = "welcome to eSence\nEnsuring Success....";  
	        StringReader reader = new StringReader(srg);  
	        int i=0;  
	            while((i=reader.read())!=-1){  
	                System.out.print((char)i);  
	            }  
	 }

}
