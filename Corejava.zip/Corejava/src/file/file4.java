package file;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class file4 {

	
	public static void main(String[] args) throws IOException {
    File f =new File("append.txt");
    f.createNewFile();
	InputStreamReader i =new InputStreamReader(System.in);
	BufferedReader br=new BufferedReader(i);
	String s=br.readLine();
	FileWriter fr=new FileWriter("append.txt", true);
	fr.write(s);
	System.out.println("String is "+s);

	}

}
