package file;

import java.io.File;
import java.io.IOException;

public class file1 {

	public static void main(String[] args) throws IOException {
    File f= new File("File1.txt");
   f.createNewFile();
	}

}
