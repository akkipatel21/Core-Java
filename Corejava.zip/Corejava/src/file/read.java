package file;
import java.io.*;

public class read {

	public static void main(String[] args) throws IOException {
		 File file = new File("read.txt");
		  BufferedReader br = new BufferedReader(new FileReader(file));
		 
		  String s;
		  while ((s = br.readLine()) != null)
		    System.out.println(s);
		  }
	
	

}

