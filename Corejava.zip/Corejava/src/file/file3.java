package file;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Writer;

import loops.breakloop;

public class file3 {

	public static void main(String[] args) throws IOException {
		FileWriter f = new FileWriter("file3.txt");
		
		BufferedWriter bf= new BufferedWriter(f);
		bf.write("eSense");
		bf.write("...");
		bf.newLine();
		bf.write("Ensuring Success");
		bf.close();
	}
		

}
