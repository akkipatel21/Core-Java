package file;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

public class mkdir {

	public static void main(String[] args) {
		  String dirname = "/1st/2nd/3rd/4th";
	      File d = new File(dirname);
	      d.mkdirs();
}
}