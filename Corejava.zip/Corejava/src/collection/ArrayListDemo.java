package collection;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListDemo {

	
	public static void main(String[] args) {
		ArrayList<String>a1= new ArrayList<String>();
		a1.add("akash");
		a1.add("parth");
		a1.add("Rutvik");
		a1.add("vishal");
		a1.add("sanjay");
		a1.add("vivek");
		
	   ArrayList<String> a2=new ArrayList<String>();  
		  a2.add("pratik"); 
		  a2.add("mauik");  
		  a2.add("chetan");
		  a1.addAll(a2);
		  Iterator it= a1.iterator();
		  while(it.hasNext()){
			  System.out.println(it.next());
		  }
		  
	}

}
