package collection;

import java.util.Scanner;

public class Logic
{

	public static void main(String[] args)
	{

		Scanner s = new Scanner(System.in);

		System.out.println("enter number of Students");

		int n = s.nextInt();
		Integer arr[] = new Integer[10];

		arr[0] = 2;
		arr[1] = 2;
		arr[2] = 2;
		arr[3] = 2;
		arr[4] = 2;
		arr[5] = 2;
		arr[6] = 2;

		System.out.println("enter elements");
		// for (int i = 0; i < n; i++){
		// {
		// arr[i] = s.nextInt();
		//
		// }
		
		for (int i = 0; i < arr.length; i++)
			{
			if (arr[i]== null) {
				System.out.println("NO");
			}
			
//			System.out.println(arr[i]);
//			if((arr[i])==null) 
//			System.out.println("Yes");
//			else
//			System.out.println("No");
			}
		}
		
	}

