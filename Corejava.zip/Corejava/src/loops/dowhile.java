package loops;

public class dowhile {

	public static void main(String[] args) {
    int x=10;
    do{
	System.out.println("the value of x: " +x);
	x++;
	}while(x<15);

}
}
