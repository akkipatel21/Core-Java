package loops;

public class enhanced_loop {

	public static void main(String[] args) {
		int numbers[]={10,20,30,40};
      for(int i: numbers){
    	  System.out.println(i);
      }
	}

}
