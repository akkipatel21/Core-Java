package arr;

import java.util.Arrays;
import java.util.Collections;

public class sort {

	
	public static void main(String[] args) {
		 int[] num = {2, 17, 5, 23, 11};
		 System.out.println("array before sorting : " + Arrays.toString(num));
		 System.out.println("sorting array in ascending order");

		 Arrays.sort(num);
		 System.out.println("array after sorting : " + Arrays.toString(num));
		        
		 String[] name = {"Akash", "Darshitsir", "Rutviksir", "Mauliksir"};
		 System.out.println("String array before sorting : " + Arrays.toString(name));
		 System.out.println("Sorting array in descending order");
		     
		 	 
		 Arrays.sort(name, Collections.reverseOrder());
		 System.out.println("array after sorting : " + Arrays.toString(name));
		 }

}
