package arr;

import java.util.Arrays;

public class ToString {

	public static void main(String args[]) {
		int[] numbers = {1, 2, 3, 4, 5, 6, 7};
		System.out.println(numbers.toString());
		
		String str = Arrays.toString(numbers);
		System.out.println("int array as String in Java : " + str); 
	
		char[] vowels = {'a', 'e', 'i', 'o', 'u'};
		System.out.println(vowels.toString()); 
		
		String charArrayAsString = Arrays.toString(vowels);
		System.out.println("char array as String in Java : " + str); 

		}
} 
	