package arr;

public class print2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int []a={1,2,3};
     for(int i=0;i<=a.length-1;i++)
    	 System.out.println(a[i]);
	
	
	}

}
