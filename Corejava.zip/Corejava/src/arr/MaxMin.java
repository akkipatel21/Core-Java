package arr;

public class MaxMin {
	public static void main(String[] args) {
	int a[]={10,11,15,78,45,72,30};
       int min=a[0];
       int max=a[0];
       for(int i=0;i<a.length;i++)
    	   {if(a[i]>max)
    		 max=a[i];
    	    if(a[i]<min)
    		   min=a[i];
    	   }
       System.out.println("max element is:"+max);
       System.out.println("max element is:"+min);
	}
}
