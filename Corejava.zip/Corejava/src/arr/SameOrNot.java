package arr;

import java.util.Arrays;

public class SameOrNot {


	public static void main(String[] args) {
		int a[]={1,2,3,4};
		int b[]={1,2,5,3,4};
				if(Arrays.equals(a, b))
					System.out.println("same");	
				else
					System.out.println("not same");
			
		
	}

}
