package arr;

public class FindLength {
		public static void main(String[] args) {
			 int a[] = {1, 99, 10000, 84849, 111, 212, 314, 21, 442, 455, 244, 554, 22, 22, 211};
             int length= a.length;
             System.out.println("length of array is "+length);
	}

}
