package arr;

public class displayAll {

	public static void Values(String[] a) {
		if (a == null) {
			System.out.println("The array has no elements.");
		} else {
			int Length = a.length;
			for (int i = 0; i <= Length - 1; i++) {
				String value = a[i];
				System.out.println("The array contains the value: " + value);
			}
		}
	}

	public static void main(String[] args) {
		String[] a= { "akash", "mauliksir", "rutviksir","pratiksir" };
		Values(null);
		Values(a);
	}
}