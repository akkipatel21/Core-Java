package arr;



public class COPY {

	public static void main(String[] args) {
		 char[] A = { 'd', 'e', 'S', 'e', 'n', 'c', 'e',
				    'i', 'n', 'a', 't', 'e', 'd' };
	        char[] B = new char[7];
	        System.arraycopy(A, 1, B, 0, 6);;
	        System.out.println(new String(B));
	}

}
