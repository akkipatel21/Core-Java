package arr;

public class multi1 {

		public static void main(String[] args) {
		  String[][] names =  {{"HELLO ", "HII ", "BYE "},
		            {"x", "y"}};
		      
		        System.out.println(names[0][0] + names[1][0]);
		        System.out.println(names[0][2] + names[1][1]);
		    }
		
	}


